import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { ListarclientesComponent } from './pages/listarclientes/listarclientes.component';
import { ModuloadministrativoComponent } from './pages/moduloadministrativo/moduloadministrativo.component';
import { BienvenidoComponent } from './pages/moduloadministrativo/bienvenido/bienvenido.component';
import { DashboardComponent } from './pages/moduloadministrativo/dashboard/dashboard.component';
import { SliderbarComponent } from './pages/moduloadministrativo/sliderbar/sliderbar.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { CategoriasComponent } from './pages/moduloadministrativo/categorias/categorias.component';


const routes: Routes = [
  {path:'', component: HomeComponent,pathMatch:'full'},
  {path:'login', component: LoginComponent,pathMatch:'full'},
  {path:'signup', component: SignupComponent,pathMatch:'full'},
  {path:'listarClientes', component: ListarclientesComponent,pathMatch:'full'},
  {path:'moduloAdmin', component: ModuloadministrativoComponent,pathMatch:'full'},
  {path:'profile', component: ProfileComponent,pathMatch:'full'},
  {path:'admin',component:DashboardComponent,
  children:[
    {
      path:'',component:BienvenidoComponent
    },
    {
      path:'slider',component:SliderbarComponent
    },
    {
      path:'categoria-view',component:CategoriasComponent
    }
  ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
