import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moduloadministrativo',
  templateUrl: './moduloadministrativo.component.html',
  styleUrls: ['./moduloadministrativo.component.css']
})
export class ModuloadministrativoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
